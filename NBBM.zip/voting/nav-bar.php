

<div class="panel-nav">
    <div class="menue">
       <center><h3 class="panel-title"><a href="index.php">Home</a> | <a href="view.php">Candidates</a> | <a href="about.php">UNILUSU</a> | <a href="voters.php">Registered Voters</a></h3></center>
    </div>
</div>
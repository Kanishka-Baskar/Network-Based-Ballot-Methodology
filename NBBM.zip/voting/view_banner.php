<style type="text/css">
nav ul li{
    display: inline-block;
    padding-left: 20px;
    padding-bottom: 10px;
}
nav ul li:hover{
    text-decoration: none;
}
a:hover{
    text-decoration: none;
}


</style>
            <div class="text-center text-success animateuse" style="background-color:rgba(0, 100, 0, 1); font-size:25px;text-align:center; margin-top:-10px; padding-top:20px;">
                <a style="color:white; font-weight:bold; font-size:30px;">Student Union Elections 2023</a>
              
        <nav class="nav-menue">
            <ul style = "color">
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li><a href="candidate_path.php">Candidates</a></li>
                <li><a href="unilusu.php">AUXCSU</a></li>
                <li> <a href="register/index.php">Register</a></li>
                <li><a href="voters.php">Voter List</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </nav>
					
</div>
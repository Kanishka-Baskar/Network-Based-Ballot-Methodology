
<footer class="footer">
	<hr/>
 Developed by III CS.
<br/>
Network Based Ballot Methodology.
<br/>
Final Year Project 2023. Auxilium College
<br/>

</footer>

<!---edit modal -->
<div class="modal hide fade"  id="e<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">

    </div>
    <div class="modal-body">

       
    </div>
    <div class="modal-footer">

        <button class="btn" data-dismiss="modal" aria-hidden="true"> <i class="icon-remove icon-large"></i>Close</button>

    </div>
</div>
<!-- end of modal -->  


	<?php }
?>